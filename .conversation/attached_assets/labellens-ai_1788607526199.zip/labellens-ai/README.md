# LabelLens AI

**AI-Powered Packaged Commodity Compliance Verification** — a frontend prototype built for Smart India Hackathon 2026.

LabelLens AI helps inspectors, manufacturers, and regulatory authorities verify whether packaged products comply with mandatory labelling and declaration requirements (Legal Metrology / FSSAI style rules). This is a **frontend-only prototype** with realistic mock data and a simulated AI analysis pipeline — it is structured so the mock logic in `src/data/mockData.js` and the simulated flow in `src/pages/Analysis.jsx` can be swapped for real calls to a FastAPI backend later.

## Tech stack

- React 18 + Vite
- React Router v6
- Tailwind CSS (custom dark "GovTech + AI" theme, see `tailwind.config.js`)
- Recharts for charts
- Framer Motion for the hero and analysis animations
- Lucide React for icons

## Getting started

Requires Node.js 18+.

```bash
npm install
npm run dev
```

Then open the printed local URL (typically `http://localhost:5173`).

To build for production:

```bash
npm run build
npm run preview
```

## App structure

```
src/
  components/       Reusable UI: Sidebar, TopBar, StatCard, ComplianceScoreRing,
                     UploadArea, AnalysisProgress, ViolationCard, StatusBadge, DashboardLayout
  pages/            LandingPage, Dashboard, ScanProduct, Analysis, ComplianceReport,
                     ScanHistory, ComplianceRules, Analytics, Settings
  data/mockData.js  All mock data for the prototype, kept in one place
  App.jsx           Route definitions
  main.jsx          Entry point (wraps App in BrowserRouter)
```

## User journey

Landing Page → Dashboard → Scan Product → Upload Image → Analyze → AI Analysis Animation → Compliance Report → Scan History / Analytics / Compliance Rules

The "Analyze Product Label" button on the Scan Product page triggers a simulated multi-step AI analysis sequence (image quality check → label detection → OCR → declaration identification → rule evaluation → report generation), then automatically navigates to a dynamically rendered Compliance Report.

## Connecting a real backend later

Two places are designed as the seams for a FastAPI backend:

1. **`src/pages/ScanProduct.jsx` / `src/pages/Analysis.jsx`** — replace the simulated step timers with a real upload (`POST /api/scan`) and poll or stream real progress/results.
2. **`src/data/mockData.js`** — replace the static exports with data fetched from your API (e.g. `GET /api/dashboard`, `GET /api/scans`, `GET /api/rules`, `GET /api/analytics`), keeping the same shapes so components don't need to change.

## Responsiveness

- **Desktop:** full fixed sidebar, collapsible via the toggle at its base.
- **Tablet:** sidebar collapses to icon-only rail.
- **Mobile:** sidebar becomes a slide-in drawer opened from the top bar; the Scan Product page's upload area and camera-capture button are optimized for phone use in the field.
