import { Routes, Route } from 'react-router-dom';
import DashboardLayout from './components/DashboardLayout.jsx';
import LandingPage from './pages/LandingPage.jsx';
import Dashboard from './pages/Dashboard.jsx';
import ScanProduct from './pages/ScanProduct.jsx';
import Analysis from './pages/Analysis.jsx';
import ComplianceReport from './pages/ComplianceReport.jsx';
import ScanHistory from './pages/ScanHistory.jsx';
import ComplianceRules from './pages/ComplianceRules.jsx';
import Analytics from './pages/Analytics.jsx';
import Settings from './pages/Settings.jsx';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />

      <Route element={<DashboardLayout />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/scan" element={<ScanProduct />} />
        <Route path="/analysis" element={<Analysis />} />
        <Route path="/report" element={<ComplianceReport />} />
        <Route path="/history" element={<ScanHistory />} />
        <Route path="/rules" element={<ComplianceRules />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/settings" element={<Settings />} />
      </Route>

      <Route path="*" element={<LandingPage />} />
    </Routes>
  );
}
